package dk.dtu.management.view;



import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class AddStatus {
	

	public AddStatus (){    
		JFrame f=new JFrame("Add status"); 
					//submit button
		JButton b=new JButton("Submit");    
					//enter name label
		
		JLabel label = new JLabel();		
		label.setText(" Enter Temp:");
					//empty label which will show event after button clicked
		
		JLabel label2 = new JLabel();
		label2.setText(" Enter Humidity:");
		
		JLabel label3 = new JLabel();
		label3.setText(" Enter Pressure:");
		
		JLabel input = new JLabel();
					//textfield to enter name
		
		JTextField textfield= new JTextField();
					//add to frame
		
		JTextField textfield2= new JTextField();
		
		JTextField textfield3= new JTextField();
		
		
		f.add(label);
		f.add(textfield);
		
		f.add(label2);
		f.add(textfield2);
		
		f.add(label3);
		f.add(textfield3);
		
		f.add(input);
		f.add(b);    
		f.setSize(300,200);    
		f.setLayout(new GridLayout(4,2));
		f.setVisible(true);    
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
		f.setResizable(false);
		
							//action listener
		b.addActionListener(new ActionListener() {
	        
			@Override
			public void actionPerformed(ActionEvent arg0) {
				input.setText(" Status added!");				
			}          
	      });
		}         
	
	
		public static void main(String[] args) {    
		    new AddStatus ();    
		}    
 }

	
